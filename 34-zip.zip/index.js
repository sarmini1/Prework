function zip(){

  let arr = Array.from(arguments);
  let obj = {};
  let result = [];

  //initialize object keys as subarray indices

  for(let i = 0;i<arr.length;i++){
    for(let k = 0;k<arr[i].length;k++){
       obj[k] = [];
    }
  }

  //push appropriate values to object key arrays via more nested loops

  for(let j = 0; j<arr.length;j++){
    for(let k = 0; k<arr[j].length;k++){
        obj[k].push(arr[j][k]);
    }
  }

  //loop through obj to make sure that all object key arrays have the same length as the initial array
    //if they don't, push undefined until they do
  //copy all key values into final result array

  for(let key in obj){
    while(obj[key].length < arr.length){
      obj[key].push(undefined);
    }
    result.push(obj[key]);
  }

  return result;

}

//Write a function called zip which accepts an arbitrary number of arrays, and creates an array of grouped elements, the first of which contains the first elements of the input arrays, the second of which contains the second elements of the input arrays, and so on.
 
//zip([1,2],[3,4]) 
// [[1, 3], [2, 4]
 
zip(['a', 'b'], [1, 2], [true, false]);
// [['a', 1, true], ['b', 2, false]]
 
//zip(['w','x','y','z']);
// [['w'], ['x'], ['y'], ['z']]
 
//zip(['a', 'b','c'], [1, 2], [true, false]);
//[['a', 1, true], ['b', 2, false], ['c', undefined, undefined]]
