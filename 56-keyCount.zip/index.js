function keyCount(arr) {

  let ans = arr.reduce((final, element) => {
    for (let key in element) {
      final[key] = (final[key] || 0) + 1;
    }
    return final;
  }, {});

  return ans;

}

//Write a function called keyCount which accepts an array of objects and returns an object with a count of how many times each key appears in the array of objects.

keyCount([
  { name: "Elie", catOwner: false },
  { name: "Moxie", isCat: true }]);
// { name: 2, catOwner: 1, isCat: 1}

//keyCount([{ age: 1, eyeColor: "blue" },
//{ age: 3, eyeColor: "brown" },
//{ age: 7, inSchool: true }]);
// { age: 3, eyeColor: 2, inSchool: 1 }