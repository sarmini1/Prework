function reverseVowels(str){

  let vowels = ['a','e','i','o','u'];
  let toReverse = [];
  let result = [];

  //loop through the initial string to identify vowels
    //push any vowel to the toReverse array

  for(let i = 0;i<str.length;i++){
    if(vowels.includes(str[i].toLowerCase())){
      toReverse.push(str[i]);
    }
  }

  //loop through initial string again
  //if ith character is not in vowels array, push to result
  //else
    //push the last value in the ToReverse array to result, then remove it
  
  for(let i = 0;i<str.length;i++){
    if(!vowels.includes(str[i].toLowerCase())){
      result.push(str[i]);
    }
    else{
      result.push(toReverse[toReverse.length-1]);
      toReverse.pop();
    }
  }

  return result.join("");

}

//Write a function called reverseVowels which accepts a string and reverses the vowels in the string.
  
//reverseVowels('amazing') // "imazang"
reverseVowels('awesome'); // "ewosema"
//reverseVowels('Rithm School') // "Rothm Schoil"