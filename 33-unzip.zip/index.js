function unzip(){

  let arr = Array.from(arguments);
  let obj = {};
  let result = [];

  for(let i = 0;i<arr.length;i++){
    for(let k = 0;k<arr[i].length;k++){
      for(let z = 0; z<arr[i][k].length;z++){
        obj[z] = [];
      }
    }
  }

  for(let i = 0;i<arr.length;i++){
    for(let k = 0;k<arr[i].length;k++){
      for(let z = 0; z<arr[i][k].length;z++){
        obj[z].push(arr[i][k][z]);
      }
    }
  }

  for(let key in obj){
    result.push(obj[key]);
  }

  return result;

}

//Write a function called unzip, which accepts an array of grouped elements and returns a new an array, which regroups the elements to their pre-zip configuration.

//unzip([[1, 2], [3, 4]]);
// [[1,3],[2,4]]

//unzip([['a', 1, true], ['b', 2, false]]);
// [['a', 'b'], [1, 2], [true, false]]

unzip([['a'],['b'],['c']]);
// [['a','b','c']]
