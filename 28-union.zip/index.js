function union() {

  let params = arguments.length;
  let arr = Array.from(arguments);
  let ans = [];

  //loop through new array of all arguments
  //loop through each subarray
  //if ans doesn't include the kth value
  //push to ans

  for (let i = 0; i < params; i++) {
    for (let k = 0; k < arr[i].length; k++) {
      if (!ans.includes(arr[i][k])) {
        ans.push(arr[i][k]);
      }
    }
  }

  return ans;

}

//union([2],[1, 2]);
union([2], [1, 2], [3], [3, 4, 5]);
//union([2],[1, 2], [6,8], [4,5,1,2], [2,7,6,9]);