function binaryToDecimal(str) {

  let sum = 0;

  //loop through given string from right to left via k, also set i at 1, incrementing i by i*2
    //if kth character is 1
      //accumulate sum by i
  //return sum

  for (let i = 1, k = str.length - 1; k > -1; i *= 2, k--) {
    if (+str[k] === 1) {
      sum += i;
    }
  }

  return sum;

}

binaryToDecimal('100010101010101010101');
//binaryToDecimal('10011101101');