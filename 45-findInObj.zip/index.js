function findInObj(arr, key, val) {

  let ans = undefined;

  //loop through the given array
  //if the ith element's key value matches our parameter value
  //set ans equal to ith element and break

  for (let i = 0; i < arr.length; i++) {
    if (arr[i][key] === val) {
      ans = arr[i];
      break;
    }
  }

  return ans;

}

var people = [
  { firstName: "Matt", lastName: "Lane" },
  { firstName: "Elie", lastName: "Schoppik" },
  { firstName: "Michael", lastName: "Hueter" },
  { firstName: "Michael", lastName: "Bolton" }
];

//findInObj(people, "lastName", "Lane");
// { firstName: "Matt", lastName: "Lane" }

findInObj(people, "firstName", "Michael");
// { firstName: "Michael", lastName: "Hueter" }

//findInObj(people, "firstName", "Tim"); // undefined
//findInObj(people, "notAKey", "notAValue"); // undefined
