function swap(arr, num1, num2) {

  [arr[num1], arr[num2]] = [arr[num2], arr[num1]];

  return arr;

}

//Write a function called swap, which accepts an array and two numbers. The function should return the array with the values at each number swapped. The function should not create a new array. You can assume that each number will be within the range of 0 and the length of the array.

var arr = [1, 2, 3, 4];
swap(arr, 0, 2);
//arr // [3,2,1,4]

var arr2 = [5, 6, 8, 7];
//swap(arr2, 2, 3);
//arr2 // [5,6,7,8]