function mergeSortedArrays(arr1, arr2) {

  let combined = arr1.concat(arr2);

  for (let i = 0; i < combined.length; i++) {
    for (let k = i + 1; k < combined.length; k++) {
      let current;
      if (combined[k] < combined[i]) {
        current = combined[i];
        combined[i] = combined[k];
        combined[k] = current;
      }
    }
  }

  return combined;

}

//Given two sorted arrays, write a function called mergeSortedArrays which accepts two arrays and returns a new array with both of the values from each array sorted. 

//As a bonus, try to implement this without using the built-in sort method.

var arr1 = [1, 3, 4, 5];
var arr2 = [2, 4, 6, 8];
//mergeSortedArrays(arr1, arr2); // [1,2,3,4,4,5,6,8]

var arr3 = [-2, -1, 0, 4, 5, 6];
var arr4 = [-3, -2, -1, 2, 3, 5, 7, 8];
mergeSortedArrays(arr3,arr4); // [-3,-2,-2,-1,-1,0,2,3,4,5,5,6,7,8]

var arr5 = [3, 4, 5];
var arr6 = [1, 2];
//mergeSortedArrays(arr5,arr6); // [1,2,3,4,5]