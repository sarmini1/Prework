function hammingDistance(str1,str2) {

  let dist = 0;
  
  //compare lengths of both strings-- if they aren't equivalent, return given statement
  //else
    //loop through string 1
      //if the ith character of string 1 doesn't equal that of string 2 (both set to lower case)
        //increment dist variable
    //return dist

  if(str1.length != str2.length){
    return "Input strings must have the same length.";
  }
  else{
    for(let i = 0;i<str1.length;i++){
      if(str1[i].toLowerCase() != str2[i].toLowerCase()){
        dist++;
      }
    }
    return dist;
  }
  
}

hammingDistance("hello", "jello") // 1
//hammingDistance("cool", "kewl") // 3
//hammingDistance("sweet", "Sweet") // 0
//hammingDistance("yoyo", "yoyoyo");